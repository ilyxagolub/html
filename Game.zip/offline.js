﻿{
	"version": 1704385161,
	"fileList": [
		"data.js",
		"c2runtime.js",
		"jquery-3.4.1.min.js",
		"offlineClient.js",
		"images/player-sheet0.png",
		"images/bullet-sheet0.png",
		"images/tiledbackground.png",
		"images/wall.png",
		"images/wallwall-sheet0.png",
		"icon-16.png",
		"icon-32.png",
		"icon-114.png",
		"icon-128.png",
		"icon-256.png",
		"loading-logo.png",
		"Photon-Javascript_SDK.min.js"
	]
}